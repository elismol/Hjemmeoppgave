import fetchCats from "../api";
import React, { useEffect, useState } from "react";

const CatApp = () => {
  const [cats, setCats] = useState([]);

  useEffect(() => {
    getCats();
  }, []);

  async function getCats() {
    const allCats = await fetchCats();
    setCats(allCats);
  }

  return (
    <>
    <div>
      <input placeholder="Search for a cat breed" />
    </div>

    {cats.map((breed) => (
        <div key={breed.id}>{breed.name}</div>
    ))}
</>
  );
};
export default CatApp;
