import fetchCats from "../api";
import React, { useEffect, useState } from "react";
import SearchBar from "./SearchBar";
import BreedInList from "./BreedInList";
import Modal from "./Modal";
import "../styles/CatApp.css";

const CatApp = () => {
  const [cats, setCats] = useState([]);
  const [searchWord, setSearchWord] = useState("");
  const [noResult, setNoResult] = useState(false);
  const [selectedBreed, setSelectedBreed] = useState(null);

  useEffect(() => {
    getCats();
  }, []);

  async function getCats() {
    try {
      const allCats = await fetchCats();
      setCats(allCats);
    } catch (error) {}
  }

  const handleSearch = (text) => {
    setSearchWord(text);
    const listLength = cats
          .filter((breed) => {
            return (
              breed.name.toLowerCase().includes(text.toLowerCase()) &&
              breed.image !== undefined
            );
          }).length
console.log(listLength)
    if(listLength === 0) {
      setNoResult(true);
    }
    else {
      setNoResult(false);
    }
  };

  const openModal = (breed) => {
    setSelectedBreed(breed);
  };

  const closeModal = () => {
    setSelectedBreed(null);
  };

  return (
    <div className="cat-app-container">
      <h1>Cat Breeds</h1>
      <SearchBar search={handleSearch} />
      {noResult ? (<p>No results found</p>) : <></>}
      <div className="cat-list">
        {cats
          .filter((breed) => {
            return (
              breed.name.toLowerCase().includes(searchWord.toLowerCase()) &&
              breed.image !== undefined
            );
          })
          .map((breed) => (
            <div
              onClick={() => openModal(breed)}
              key={breed.id}
              className="cat-item"
            >
              <BreedInList name={breed.name} imageURL={breed.image.url} />
            </div>
          ))}
      </div>
      {selectedBreed && (
        <Modal
          name={selectedBreed.name}
          imageURL={selectedBreed.image.url}
          description={selectedBreed.description}
          lifespan={selectedBreed.life_span}
          origin={selectedBreed.origin}
          onClose={closeModal}
        />
      )}
    </div>
  );
};

export default CatApp;
