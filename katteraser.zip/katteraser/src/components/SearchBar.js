import React from "react";
/* Brukte chatgpt for å generere noe av denne stylingen */
const SearchBar = ({ search }) => {
  const inputStyle = {
    padding: '8px',
    borderRadius: '5px',
    border: '1px solid #ccc',
    maxWidth: '300px',
    width: '100%',
    fontSize: '16px',
  };

  return (
    <div>
      <input
        style={inputStyle}
        onChange={(e) => {
          search(e.target.value);
        }}
        placeholder="Search for a cat breed"
      />
    </div>
  );
};

export default SearchBar;
