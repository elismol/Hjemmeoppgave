import React from "react";
import "../styles/Modal.css";

const Modal = ({ name, imageURL, description, lifespan, origin, onClose }) => {
  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <button className="close-button" onClick={onClose}>
          Close
        </button>
        <div className="modal-inner">
          <h2>{name}</h2>
          <div className="modal-image">
            <img src={imageURL} alt={name} />
          </div>
          <div className="modal-details">
            <p><span>Description:</span> {description}</p>
            <p><span>Origin:</span> {origin}</p>
            <p><span>Lifespan:</span> {lifespan}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Modal;
