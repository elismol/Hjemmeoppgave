/* Brukte chatgpt for å generere noe av denne stylingen */
const BreedInList = ({ name, imageURL }) => {
    const containerStyle = {
      display: 'flex',
      alignItems: 'center',
      padding: '10px',
      borderBottom: '1px solid #ccc',
      maxWidth: '80%',
      margin: '0 auto',
    };
  
    const imageStyle = {
      width: '100px', 
      height: '100px', 
      marginRight: '10px', 
    };
  
    return (
      <div style={containerStyle}>
        <img src={imageURL} alt={name} style={imageStyle} />
        <h3><span>{name}</span></h3>
      </div>
    );
  };
  
  export default BreedInList;
  