const API_URL = 'https://api.thecatapi.com/v1/breeds?limit=100&page=0&api_key=live_HQ2p2jHlCzLlVWK1G8ZjfFbqZWzBHewj6VhHfrDpdx5DLCVO58PCKRFrq8kYJLdZ';


export default async function fetchCats() {
    try{
        const response = await fetch(API_URL);
        const jsonData = await response.json();
        return jsonData;
    } catch (error) {
        console.log("error", error);
        throw error;
    }
};

