import React from "react";
import './App.css';
import CatApp from "./components/CatApp";


function App() {
  return (
    <CatApp/>
  );

}

export default App;
